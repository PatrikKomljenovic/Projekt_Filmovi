package projektFilmovi1;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

public class BrisanjeFilmova {

    private JFrame frame;
    private JList<String> listaFilmova;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    BrisanjeFilmova window = new BrisanjeFilmova();
                    window.showWindow(); 
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public BrisanjeFilmova() {
        initialize();
        popuniListuFilmova();
    }


    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 809, 386);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblNaslov = new JLabel("Lista Filmova");
        lblNaslov.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblNaslov.setBounds(10, 10, 200, 30);
        frame.getContentPane().add(lblNaslov);

        listaFilmova = new JList<>();
        listaFilmova.setBounds(10, 50, 200, 150);
        frame.getContentPane().add(listaFilmova);

        JScrollPane scrollPane = new JScrollPane(listaFilmova);
        scrollPane.setBounds(10, 50, 200, 150);
        frame.getContentPane().add(scrollPane);

        JButton btnObrisiFilm = new JButton("Obriši film");
        btnObrisiFilm.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                obrisiFilm();
                popuniListuFilmova(); 
            }
        });
        btnObrisiFilm.setBounds(20, 210, 178, 30);
        frame.getContentPane().add(btnObrisiFilm);
    }

    private void popuniListuFilmova() {
        DefaultListModel<String> model = new DefaultListModel<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://student.veleri.hr/pkomljenovic?serverTimezone=UTC";
            String korisnik = "pkomljenovic";
            String lozinka = "11";

            Connection connection = DriverManager.getConnection(url, korisnik, lozinka);

            String sql = "SELECT Naslov, Zanr, Ocjena FROM FilmoviOOOP";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String naslov = resultSet.getString("Naslov");
                String zanr = resultSet.getString("Zanr");
                double ocjena = resultSet.getDouble("Ocjena");

                String filmInfo = naslov + " - " + zanr + " - " + ocjena;
                model.addElement(filmInfo);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Došlo je do pogreške prilikom dohvaćanja podataka.");
        }

        listaFilmova.setModel(model);
    }

    private void obrisiFilm() {
        try {
            String selectedFilmInfo = listaFilmova.getSelectedValue();
            String naslov = selectedFilmInfo.split(" - ")[0]; 

            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://student.veleri.hr/pkomljenovic?serverTimezone=UTC";
            String korisnik = "pkomljenovic";
            String lozinka = "11";

            Connection connection = DriverManager.getConnection(url, korisnik, lozinka);

            String sql = "DELETE FROM FilmoviOOOP WHERE Naslov=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, naslov);

            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(frame, "Film uspješno obrisan iz baze.");
            } else {
                JOptionPane.showMessageDialog(frame, "Film s odabranim naslovom nije pronađen.");
            }

            preparedStatement.close();
            connection.close();

        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Došlo je do pogreške prilikom brisanja filma.");
        }
    }

    public void showWindow() {
        frame.setVisible(true);
    }
}
