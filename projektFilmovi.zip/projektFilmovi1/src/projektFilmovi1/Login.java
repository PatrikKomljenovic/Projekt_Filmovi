package projektFilmovi1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

public class Login {

    private JFrame frame;
    private JTextField brojMob;
    private JPasswordField lozinka;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Login window = new Login();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Login() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 589, 409);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Broj mobitela");
        lblNewLabel.setBounds(92, 98, 76, 14);
        frame.getContentPane().add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Lozinka");
        lblNewLabel_1.setBounds(92, 199, 46, 14);
        frame.getContentPane().add(lblNewLabel_1);

        brojMob = new JTextField();
        brojMob.setBounds(238, 95, 86, 20);
        frame.getContentPane().add(brojMob);
        brojMob.setColumns(10);

        lozinka = new JPasswordField();
        lozinka.setBounds(236, 196, 88, 20);
        frame.getContentPane().add(lozinka);

        JButton btnNewButton = new JButton("LOGIRAJ");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String brojMobs, lozinkas;
                brojMobs = brojMob.getText();
                lozinkas = new String(lozinka.getPassword());

                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/pkomljenovic?serverTimezone=UTC", "pkomljenovic", "11");
                    String upit = "SELECT * FROM registracija WHERE brojMob=? and lozinka=?";
                    PreparedStatement ps = con.prepareStatement(upit);
                    ps.setString(1, brojMobs);
                    ps.setString(2, lozinkas);
                    ResultSet rs = ps.executeQuery();

                    if (rs.next()) {
                        // Provjera lozinke
                        String lozinkaIzBaze = rs.getString("lozinka");
                        if ("stol".equals(lozinkaIzBaze)) {
                            GlavniIzbornik gi = new GlavniIzbornik();
                            gi.showWindow();
                        } else {
                            UneseniFilmovi uf = new UneseniFilmovi();
                            uf.showWindow();
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Login nije moguć; podatci ne odgovaraju");
                    }
                } catch (Exception e1) {
                    JOptionPane.showMessageDialog(null, "Greška servera");
                }
            }
        });
        btnNewButton.setBounds(210, 304, 89, 23);
        frame.getContentPane().add(btnNewButton);
    }

    public void showWindow() {
        frame.setVisible(true);
    }
}
