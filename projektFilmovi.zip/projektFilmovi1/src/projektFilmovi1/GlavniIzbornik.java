package projektFilmovi1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GlavniIzbornik {

    private JFrame frame;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    GlavniIzbornik window = new GlavniIzbornik();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public GlavniIzbornik() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 530, 564);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JButton UnosFilma = new JButton("Unos Filma");
        UnosFilma.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UnosFilma unosFilma = new UnosFilma();
                unosFilma.showWindow();
            }
        });
        UnosFilma.setBounds(152, 59, 186, 83);
        frame.getContentPane().add(UnosFilma);

        JButton UredivanjeFilma = new JButton("Promjena Podataka Filma");
        UredivanjeFilma.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UredivanjeFilma uredivanjeFilma = new UredivanjeFilma(); 
                uredivanjeFilma.showWindow();
            }
        });
        UredivanjeFilma.setBounds(152, 152, 186, 83);
        frame.getContentPane().add(UredivanjeFilma);

        JButton PregledFilmova = new JButton("Pregled Filmova");
        PregledFilmova.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                UneseniFilmovi uneseniFilmovi = new UneseniFilmovi(); 
                uneseniFilmovi.showWindow();
            }
        });
        PregledFilmova.setBounds(152, 245, 186, 83);
        frame.getContentPane().add(PregledFilmova);

        JButton BrisanjeFilmova = new JButton("Brisanje filmova");
        BrisanjeFilmova.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                BrisanjeFilmova brisanjeFilmova = new BrisanjeFilmova();
                brisanjeFilmova.showWindow();
            }
        });
        BrisanjeFilmova.setBounds(152, 338, 186, 83);
        frame.getContentPane().add(BrisanjeFilmova);
    }

    public void showWindow() {
        frame.setVisible(true);
    }
}
