package projektFilmovi1;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class UneseniFilmovi {

    private JFrame frame;
    private JTable table;
    private JTextArea recenzijaTextArea;
    private int odabraniRed;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UneseniFilmovi window = new UneseniFilmovi();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public UneseniFilmovi() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 728, 533);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 11, 564, 250);
        frame.getContentPane().add(scrollPane);

        table = new JTable();
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                odabraniRed = table.rowAtPoint(evt.getPoint());
            }
        });
        scrollPane.setViewportView(table);

        JButton btnPrikazi = new JButton("Prikazi Filmove");
        btnPrikazi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                prikaziPodatkeIzBaze();
            }
        });
        btnPrikazi.setBounds(10, 290, 150, 30);
        frame.getContentPane().add(btnPrikazi);

        JButton btnPrikaziRecenziju = new JButton("Prikazi Recenziju");
        btnPrikaziRecenziju.setBounds(180, 290, 150, 30);
        btnPrikaziRecenziju.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                prikaziRecenziju();
            }
        });
        frame.getContentPane().add(btnPrikaziRecenziju);

        recenzijaTextArea = new JTextArea();
        recenzijaTextArea.setEditable(false);
        JScrollPane recenzijaScrollPane = new JScrollPane(recenzijaTextArea);
        recenzijaScrollPane.setBounds(10, 330, 564, 100);
        recenzijaScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        frame.getContentPane().add(recenzijaScrollPane);
    }

    private void prikaziPodatkeIzBaze() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://student.veleri.hr/pkomljenovic?serverTimezone=UTC";
            String korisnik = "pkomljenovic";
            String lozinka = "11";

            try (Connection connection = DriverManager.getConnection(url, korisnik, lozinka)) {
                String sql = "SELECT Naslov, Zanr, Ocjena, recenzija FROM FilmoviOOOP";
                try (PreparedStatement preparedStatement = connection.prepareStatement(sql);
                     ResultSet resultSet = preparedStatement.executeQuery()) {

                    DefaultTableModel model = new DefaultTableModel();
                    model.addColumn("Naslov");
                    model.addColumn("Zanr");
                    model.addColumn("Ocjena");

                    while (resultSet.next()) {
                        model.addRow(new Object[]{
                                resultSet.getString("Naslov"),
                                resultSet.getString("Zanr"),
                                resultSet.getDouble("Ocjena"),
                                resultSet.getString("recenzija")
                        });
                    }

                    table.setModel(model);
                }
            }

            // Resetiranje recenzije
            recenzijaTextArea.setText("");

        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void prikaziRecenziju() {
        if (odabraniRed == -1) {
            recenzijaTextArea.setText("Molimo odaberite film iz tablice.");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://student.veleri.hr/pkomljenovic?serverTimezone=UTC";
            String korisnik = "pkomljenovic";
            String lozinka = "11";

            try (Connection connection = DriverManager.getConnection(url, korisnik, lozinka)) {
                String sql = "SELECT recenzija FROM FilmoviOOOP WHERE Naslov = ?";
                DefaultTableModel model = (DefaultTableModel) table.getModel();
                String naslov = model.getValueAt(odabraniRed, 0).toString(); 
                try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                    preparedStatement.setString(1, naslov);
                    try (ResultSet resultSet = preparedStatement.executeQuery()) {
                        if (resultSet.next()) {
                            String recenzija = resultSet.getString("recenzija");
                            recenzijaTextArea.setText(recenzija);
                        } else {
                            recenzijaTextArea.setText("Recenzija nije dostupna.");
                        }
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void showWindow() {
        frame.setVisible(true);
    }
}
