package projektFilmovi1;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Registracija {

    private JFrame frame;
    private JTextField ime;
    private JTextField prezime;
    private JTextField brojMob;
    private JPasswordField lozinka;
    private JPasswordField ponLozinka;


    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Registracija window = new Registracija();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public Registracija() {
        initialize();
    }


    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 489, 493);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Ime");
        lblNewLabel.setBounds(70, 78, 46, 14);
        frame.getContentPane().add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Prezime");
        lblNewLabel_1.setBounds(70, 133, 46, 14);
        frame.getContentPane().add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("Broj mobitela");
        lblNewLabel_2.setBounds(30, 202, 86, 14);
        frame.getContentPane().add(lblNewLabel_2);

        JLabel lblNewLabel_3 = new JLabel("Lozinka");
        lblNewLabel_3.setBounds(70, 261, 46, 14);
        frame.getContentPane().add(lblNewLabel_3);

        JLabel lblNewLabel_4 = new JLabel("Ponovljena lozinka");
        lblNewLabel_4.setBounds(30, 313, 112, 14);
        frame.getContentPane().add(lblNewLabel_4);

        ime = new JTextField();
        ime.setBounds(187, 76, 84, 20);
        frame.getContentPane().add(ime);
        ime.setColumns(10);

        prezime = new JTextField();
        prezime.setBounds(187, 131, 84, 20);
        frame.getContentPane().add(prezime);
        prezime.setColumns(10);

        brojMob = new JTextField();
        brojMob.setBounds(187, 200, 84, 20);
        frame.getContentPane().add(brojMob);
        brojMob.setColumns(10);

        lozinka = new JPasswordField();
        lozinka.setBounds(187, 259, 84, 20);
        frame.getContentPane().add(lozinka);

        ponLozinka = new JPasswordField();
        ponLozinka.setBounds(187, 311, 84, 20);
        frame.getContentPane().add(ponLozinka);

        JButton btnNewButton = new JButton("REGISTRIRAJ");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                String imes, prezimes, brojMobs, lozinkas, ponLozinkas;

                imes = ime.getText();
                prezimes = prezime.getText();
                brojMobs = brojMob.getText();

                lozinkas = new String(lozinka.getPassword());
                ponLozinkas = new String(ponLozinka.getPassword());

                if (lozinkas.equals(ponLozinkas)) {
                    try {
                        Class.forName("com.mysql.cj.jdbc.Driver");
                        Connection con = DriverManager.getConnection("jdbc:mysql://student.veleri.hr/pkomljenovic?serverTimezone=UTC", "pkomljenovic", "11");
                        String upit = "SELECT * FROM registracija WHERE brojMob=?";
                        PreparedStatement ps = con.prepareStatement(upit);
                        ps.setString(1, brojMobs);
                        ResultSet rs = ps.executeQuery();

                        if (rs.next()) {
                            JOptionPane.showMessageDialog(null, "Registracija nije moguća; korisnik s tim brojem mobitela već postoji u bazi");
                        } else {
                            String insert = "INSERT INTO registracija(ime, prezime, brojMob, lozinka) VALUES (?,?,?,?)";
                            PreparedStatement psInsert = con.prepareStatement(insert);
                            psInsert.setString(1, imes);
                            psInsert.setString(2, prezimes);
                            psInsert.setString(3, brojMobs);
                            psInsert.setString(4, lozinkas);

                            int ubacenoRedaka = psInsert.executeUpdate();

                            if (ubacenoRedaka == 1) {
                                JOptionPane.showMessageDialog(null, "Registracija uspješna");

                                // Poziv za otvaranje Login prozora nakon uspješne registracije
                                Login login = new Login();
                                login.showWindow();

                                
                                frame.dispose();
                            } else {
                                JOptionPane.showMessageDialog(null, "Registracija neuspješna");
                            }
                        }

                    } catch (Exception e1) {
                        JOptionPane.showMessageDialog(null, "Greška prilikom spajanja na server");
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Lozinke se ne podudaraju");
                }

            }
        });
        btnNewButton.setBounds(163, 403, 125, 23);
        frame.getContentPane().add(btnNewButton);
    }

    public void showWindow() {
        frame.setVisible(true);
    }
}
