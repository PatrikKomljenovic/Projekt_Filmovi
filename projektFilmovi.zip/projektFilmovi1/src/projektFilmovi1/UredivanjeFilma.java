package projektFilmovi1;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class UredivanjeFilma {

    // Dodana ova linija kako bi se frame mogao koristiti u metodi prikaziProzor
    public JFrame frame;
    private JTextField naslovFilmaTextField;
    private JTextField Ocjena;
    private JTextArea Naslov;
    private JComboBox<String> Zanr;
    private JTextPane recenzija;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    UredivanjeFilma window = new UredivanjeFilma();
                    window.showWindow(); // Dodao sam poziv metode showWindow() umjesto frame.setVisible(true)
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public UredivanjeFilma() {
        initialize();
    }


    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 941, 474);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        naslovFilmaTextField = new JTextField();
        naslovFilmaTextField.setBounds(202, 14, 283, 22);
        frame.getContentPane().add(naslovFilmaTextField);
        naslovFilmaTextField.setColumns(10);

        JLabel lblNaslovFilma = new JLabel("Naslov filma:");
        lblNaslovFilma.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblNaslovFilma.setBounds(39, 14, 139, 22);
        frame.getContentPane().add(lblNaslovFilma);

        Naslov = new JTextArea();
        Naslov.setBounds(202, 52, 283, 22);
        frame.getContentPane().add(Naslov);

        JLabel naslov = new JLabel("Naslov filma");
        naslov.setFont(new Font("Tahoma", Font.PLAIN, 21));
        naslov.setBounds(39, 49, 139, 22);
        frame.getContentPane().add(naslov);

        JLabel lblNewLabel = new JLabel("Ocjena (1-10)");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 21));
        lblNewLabel.setBounds(39, 108, 139, 22);
        frame.getContentPane().add(lblNewLabel);

        Ocjena = new JTextField();
        Ocjena.setBounds(202, 114, 60, 22);
        frame.getContentPane().add(Ocjena);
        Ocjena.setColumns(10);

        Zanr = new JComboBox<>();
        Zanr.setBounds(572, 53, 139, 22);
        frame.getContentPane().add(Zanr);

        Zanr.addItem("Drama");
        Zanr.addItem("Akcija");
        Zanr.addItem("Komedija");
        Zanr.addItem("Horor");
        Zanr.addItem("Krimi");
        Zanr.addItem("Sci-Fi");
        Zanr.addItem("Fantastika");
        Zanr.addItem("Romantični");

        recenzija = new JTextPane();
        recenzija.setBounds(49, 228, 608, 153);
        frame.getContentPane().add(recenzija);

        JLabel Recenzija = new JLabel("Kratka recenzija:");
        Recenzija.setFont(new Font("Tahoma", Font.PLAIN, 21));
        Recenzija.setBounds(39, 168, 183, 53);
        frame.getContentPane().add(Recenzija);

        JButton btnDohvatiPodatke = new JButton("Dohvati podatke");
        btnDohvatiPodatke.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dohvatiPodatkeOFilmu();
            }
        });
        btnDohvatiPodatke.setBounds(496, 14, 150, 25);
        frame.getContentPane().add(btnDohvatiPodatke);

        JButton btnSpremiIzmjene = new JButton("Spremi izmjene");
        btnSpremiIzmjene.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                spremiIzmjeneUBazu();
            }
        });
        btnSpremiIzmjene.setBounds(700, 350, 150, 30);
        frame.getContentPane().add(btnSpremiIzmjene);
    }

    private void dohvatiPodatkeOFilmu() {
        try {
            String naslovFilma = naslovFilmaTextField.getText();

            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://student.veleri.hr/pkomljenovic?serverTimezone=UTC";
            String korisnik = "pkomljenovic";
            String lozinka = "11";

            Connection connection = DriverManager.getConnection(url, korisnik, lozinka);

            String sql = "SELECT * FROM FilmoviOOOP WHERE Naslov = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, naslovFilma);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                Naslov.setText(resultSet.getString("Naslov"));
                Ocjena.setText(String.valueOf(resultSet.getDouble("Ocjena")));
                Zanr.setSelectedItem(resultSet.getString("Zanr"));
                recenzija.setText(resultSet.getString("recenzija"));
            } else {
                JOptionPane.showMessageDialog(frame, "Film s unesenim naslovom nije pronađen.");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();

        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Došlo je do pogreške prilikom dohvaćanja podataka.");
        }
    }

    private void spremiIzmjeneUBazu() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://student.veleri.hr/pkomljenovic?serverTimezone=UTC";
            String korisnik = "pkomljenovic";
            String lozinka = "11";

            Connection connection = DriverManager.getConnection(url, korisnik, lozinka);

            String sql = "UPDATE FilmoviOOOP SET Naslov=?, Zanr=?, Ocjena=?, recenzija=? WHERE Naslov=?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, Naslov.getText());
            preparedStatement.setString(2, Zanr.getSelectedItem().toString());
            preparedStatement.setDouble(3, Double.parseDouble(Ocjena.getText()));
            preparedStatement.setString(4, recenzija.getText());
            preparedStatement.setString(5, naslovFilmaTextField.getText());

            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();

            JOptionPane.showMessageDialog(frame, "Izmjene uspješno spremljene u bazu.");

        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Došlo je do pogreške prilikom spremanja izmjena u bazu.");
        }
    }

    
    public void showWindow() {
        frame.setVisible(true);
    }
}
